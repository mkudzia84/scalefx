/**
 * @file tas5825_m_codec.cpp
 * @brief Implementation of the TAS5825M (smart-amp variant) driver.
 *
 * Register addresses, bit fields, and state machine follow the TI
 * TAS5825M datasheet SLASEH7H (the gold standard — see tas5825_regs.h).
 * The M-specific guard rails are load-bearing:
 *   - DIS_DSP (DEVICE_CTRL2[4]) stays SET until I2S clocks are stable
 *     (datasheet: clearing it early desyncs the DSP DMA channels);
 *   - FAULT_CLEAR before config, after config, and after PLAY;
 *   - FS_MON polled for a valid rate code before HIZ → PLAY;
 *   - GPIO1 routed to FAULTZ (0x0B) WITH its output enable in GPIO_CTRL.
 * Bench mirror: tests/hw/tas5825m_beep.
 */

#if defined(SFX_HAS_AUDIO)

#include "tas5825_m_codec.h"
#include "tas5825_regs.h"
#include "../audio/audio_log.h"
#include "../audio/audio_config.h"   // AUDIO_BIT_DEPTH
#include "platform/sfx_platform.h"

namespace {

using namespace sfx_audio::tas5825;

// SAP_CTRL_1 (0x33) value picked from AUDIO_BIT_DEPTH at compile time.
// Bits [5:4] = 00 keep I2S (Philips) format; [1:0] = word length, which
// MUST match the I2S TX bit width (silicon reset default is 24-bit).
constexpr uint8_t SAP_CTRL1_FOR_BIT_DEPTH =
    (AUDIO_BIT_DEPTH == 32) ? SAP_WORD_32BIT :
    (AUDIO_BIT_DEPTH == 24) ? SAP_WORD_24BIT :
                              SAP_WORD_16BIT;

// FS_MON polling cadence used during activate().
constexpr uint32_t FS_MON_POLL_INTERVAL_MS = 5;
constexpr uint32_t FS_MON_POLL_TIMEOUT_MS  = 500;

// DEVICE_CTRL2 parking value while clocks are absent: DSP held in
// reset + soft mute + deep sleep.
constexpr uint8_t CTRL_PARKED = CTRL_DIS_DSP_BIT | CTRL_MUTE_BIT | CTRL_DEEP_SLEEP;

}  // namespace

// ─── Construction ─────────────────────────────────────────────────────────

TAS5825MCodec::TAS5825MCodec() = default;

// ─── Phase 1: pre-clock init ──────────────────────────────────────────────

bool TAS5825MCodec::begin(sfx_peripherals::SfxI2cBus& wire, int sda, int scl,
                          uint32_t sample_rate, Supply supply) {
    bool needWireInit = (i2c_ != &wire || sdaPin_ != sda || sclPin_ != scl);

    i2c_       = &wire;
    sdaPin_    = sda;
    sclPin_    = scl;
    sampleRate_ = sample_rate;
    supply_    = supply;

    if (needWireInit) {
        i2c_->begin(sdaPin_, sclPin_, 100000);   // native bus bring-up (100 kHz)
    }

    TAS5825_LOG("TAS5825M: probing @ 0x%02X (SDA=%d SCL=%d)...",
                I2C_ADDR, sdaPin_, sclPin_);

    // I2C probe with retry — bus may be transiently unavailable post-boot.
    constexpr int PROBE_RETRIES = 3;
    constexpr int PROBE_DELAY_MS = 500;
    bool probeOk = false;
    for (int attempt = 0; attempt < PROBE_RETRIES; attempt++) {
        probeOk = i2c_->probe(I2C_ADDR);
        if (probeOk) break;
        if (attempt < PROBE_RETRIES - 1) {
            TAS5825_LOG("  probe %d/%d failed, retry in %dms",
                        attempt + 1, PROBE_RETRIES, PROBE_DELAY_MS);
            SFX_DELAY_MS(PROBE_DELAY_MS);
        }
    }
    if (!probeOk) {
        TAS5825_LOG("TAS5825M: probe FAILED — check wiring/DVDD");
        initialized_ = false;
        return false;
    }

    // Identity: DIE_ID reads 0x95 on TAS5825M silicon.
    selectBookPage(BOOK_00, PAGE_00);
    uint8_t dieId = 0;
    readRegister(REG_DIE_ID, &dieId);
    TAS5825_LOG("TAS5825M: probe OK, DIE_ID=0x%02X (%s)",
                dieId, dieId == DIE_ID_TAS5825M ? "TAS5825M" : "UNEXPECTED");

    // Phase 1: park with the DSP held in reset (DIS_DSP must stay set
    // until I2S clocks are stable), full reset, re-park, clear the
    // boot-time clock-fault latch (clocks were absent at power-up).
    writeRegister(REG_DEVICE_CTRL2, CTRL_PARKED);
    SFX_DELAY_MS(5);

    writeRegister(REG_RESET_CTRL, 0x11);   // RST_DIG_CORE + RST_REG
    SFX_DELAY_MS(50);

    selectBookPage(BOOK_00, PAGE_00);
    writeRegister(REG_DEVICE_CTRL2, CTRL_PARKED);
    writeRegister(REG_FAULT_CLEAR, FAULT_CLEAR_CMD);
    SFX_DELAY_MS(5);

    initialized_ = true;
    smartAmpOn_  = false;

    TAS5825_LOG("TAS5825M: phase 1 done — parked (DSP held), fault latch "
                "cleared (SR=%lu, supply=%s)",
                sampleRate_, supplyStr(supply_));
    return true;
}

bool TAS5825MCodec::begin(uint32_t /*sample_rate*/) {
    TAS5825_LOG("TAS5825M: must call begin(Wire, sda, scl, ...)");
    return false;
}

// ─── Phase 2: post-clock activation (M-specific) ──────────────────────────

bool TAS5825MCodec::activate() {
    if (!initialized_ || !i2c_) {
        TAS5825_LOG("TAS5825M: activate() before begin()");
        return false;
    }

    TAS5825_LOG("TAS5825M: phase 2 — configuring (I2S clocks must be running)");

    // Step 1: analog gain for the configured supply voltage.
    if (!configureAnalogGain()) {
        TAS5825_LOG("TAS5825M: analog-gain config failed");
        return false;
    }

    // Step 2: serial audio port. FS/SCLK detection is automatic
    // (SIG_CH_CTRL FSMODE=0, CLOCK_DET_CTRL default); the one field
    // that must match the wire is the SAP word length.
    selectBookPage(BOOK_00, PAGE_00);
    writeRegister(REG_SIG_CH_CTRL, 0x00);
    writeRegister(REG_SDOUT_SEL, 0x00);
    writeRegister(REG_SAP_CTRL1, SAP_CTRL1_FOR_BIT_DEPTH);

    // Step 3: route GPIO1 to FAULTZ so the fault line reflects real
    // codec faults. GPIO_SEL alone is not enough — the pin also needs
    // its output enable in GPIO_CTRL. (On the M, GPIO_SEL value 0x01
    // is reserved — Table 9-42.)
    writeRegister(REG_GPIO_CTRL, GPIO1_OE);
    writeRegister(REG_GPIO1_SEL, GPIO_SEL_FAULTZ);

    // Step 4: DSP stays on silicon defaults — ROM mode 1 with ZROM
    // coefficients (DSP_PGM_MODE/DSP_CTRL reset values), which is the
    // documented pass-through configuration. Custom coefficients are
    // a PPC3 export and belong to the smart-amp pipeline.

    writeRegister(REG_DIG_VOL, currentVolume_);

    // Step 5: mid-config fault clear (config writes can tickle the
    // clock-fault latch as auto-detect re-evaluates).
    writeRegister(REG_FAULT_CLEAR, FAULT_CLEAR_CMD);
    SFX_DELAY_MS(5);

    // Step 6: FS_MON gate — wait for a valid sample-rate code BEFORE
    // releasing the DSP and transitioning to PLAY. 48 kHz reports 0x09
    // (Table 9-19).
    uint8_t fsCode = 0;
    if (!waitForFsLock(FS_MON_POLL_TIMEOUT_MS, &fsCode)) {
        uint8_t clkStat = 0;
        readRegister(REG_CLKDET_STATUS, &clkStat);
        TAS5825_LOG("TAS5825M: FS_MON never locked (CLKDET_STATUS=0x%02X) — "
                    "check BCLK/LRCLK wiring", clkStat);
        return false;
    }
    TAS5825_LOG("TAS5825M: FS_MON locked at %s (code 0x%02X)",
                fsMonStr(fsCode), fsCode);

    // Step 7: HIZ with the DSP released (DIS_DSP → 0 now that clocks
    // are proven stable), still soft-muted.
    selectBookPage(BOOK_00, PAGE_00);
    writeRegister(REG_DEVICE_CTRL2, CTRL_MUTE_BIT | CTRL_HIZ);
    SFX_DELAY_MS(20);

    // Step 8: HIZ → PLAY, un-muted.
    writeRegister(REG_DEVICE_CTRL2, CTRL_PLAY);
    SFX_DELAY_MS(20);

    // Step 9: post-PLAY clear — modulator inrush can briefly assert
    // PVDD_UV.
    writeRegister(REG_FAULT_CLEAR, FAULT_CLEAR_CMD);
    SFX_DELAY_MS(50);

    uint8_t powerState = 0;
    readRegister(REG_POWER_STATE, &powerState);
    bool inPlay = (powerState == CTRL_PLAY);

    if (inPlay) {
        TAS5825_LOG("TAS5825M: PLAY OK (FS=%s)", fsMonStr(fsCode));
    } else {
        uint8_t g1 = 0, chf = 0;
        readRegister(REG_GLOBAL_FAULT1, &g1);
        readRegister(REG_CHAN_FAULT, &chf);
        TAS5825_LOG("TAS5825M: PLAY FAILED — POWER_STATE=0x%02X (%s) "
                    "GLOBAL_FAULT1=0x%02X CHAN_FAULT=0x%02X",
                    powerState, powerStateStr(powerState), g1, chf);
    }
    return inPlay;
}

// ─── Volume / mute / reset ────────────────────────────────────────────────

void TAS5825MCodec::setVolume(float volume) {
    if (!initialized_) return;

    if (volume < 0.0f) volume = 0.0f;
    if (volume > 1.0f) volume = 1.0f;

    // Map [0..1] linearly in dB onto [mute .. 0 dB]. 0x4C counts are
    // −0.5 dB each above the 0x30 = 0 dB reference (Table 9-24);
    // gain above 0 dB is deliberately not exposed here.
    if (volume <= 0.0f) {
        currentVolume_ = VOL_MUTE;
    } else {
        int v = VOL_0DB + static_cast<int>((1.0f - volume) * 206.0f + 0.5f);
        currentVolume_ = (v > VOL_MIN) ? VOL_MIN : static_cast<uint8_t>(v);
    }

    if (!muted_) {
        selectBookPage(BOOK_00, PAGE_00);
        writeRegister(REG_DIG_VOL, currentVolume_);
        TAS5825_LOG("TAS5825M: vol = %.0f%% (0x%02X)",
                    volume * 100.0f, currentVolume_);
    }
}

void TAS5825MCodec::setVolumeDB(float db) {
    if (!initialized_) return;
    currentVolume_ = volRegForDb(db);
    if (!muted_) {
        selectBookPage(BOOK_00, PAGE_00);
        writeRegister(REG_DIG_VOL, currentVolume_);
        TAS5825_LOG("TAS5825M: vol = %.1fdB (0x%02X)", db, currentVolume_);
    }
}

void TAS5825MCodec::setMute(bool mute) {
    if (!initialized_) return;
    muted_ = mute;
    selectBookPage(BOOK_00, PAGE_00);
    if (mute) {
        writeRegister(REG_DIG_VOL, VOL_MUTE);
        TAS5825_LOG("TAS5825M: muted");
    } else {
        writeRegister(REG_DIG_VOL, currentVolume_);
        TAS5825_LOG("TAS5825M: unmuted");
    }
}

void TAS5825MCodec::reset() {
    if (!initialized_) return;
    TAS5825_LOG("TAS5825M: reset");
    selectBookPage(BOOK_00, PAGE_00);
    writeRegister(REG_DEVICE_CTRL2, CTRL_PARKED);
    writeRegister(REG_RESET_CTRL, 0x11);
    SFX_DELAY_MS(50);

    initialized_ = false;
    smartAmpOn_  = false;
    if (begin(*i2c_, sdaPin_, sclPin_, sampleRate_, supply_)) {
        activate();
    }
}

bool TAS5825MCodec::setSupplyVoltage(Supply voltage) {
    if (!initialized_) return false;
    if (voltage == supply_) return true;
    TAS5825_LOG("TAS5825M: supply %s -> %s", supplyStr(supply_), supplyStr(voltage));

    // Briefly park to change analog gain safely (AGAIN mid-PLAY pops).
    selectBookPage(BOOK_00, PAGE_00);
    writeRegister(REG_DEVICE_CTRL2, CTRL_MUTE_BIT | CTRL_HIZ);
    SFX_DELAY_MS(2);

    supply_ = voltage;
    bool ok = configureAnalogGain();

    writeRegister(REG_DEVICE_CTRL2, CTRL_PLAY);
    writeRegister(REG_FAULT_CLEAR, FAULT_CLEAR_CMD);
    if (!ok) TAS5825_LOG("TAS5825M: analog gain reconfigure failed");
    return ok;
}

// ─── Fault management ─────────────────────────────────────────────────────

bool TAS5825MCodec::clearFaults() {
    if (!initialized_) return false;
    selectBookPage(BOOK_00, PAGE_00);
    return writeRegister(REG_FAULT_CLEAR, FAULT_CLEAR_CMD);
}

uint8_t TAS5825MCodec::readFaultRegister() {
    if (!initialized_) return 0xFF;
    selectBookPage(BOOK_00, PAGE_00);
    uint8_t v = 0;
    readRegister(REG_GLOBAL_FAULT1, &v);
    return v;
}

// ─── Smart-amp / IV-sense API (M-only) ────────────────────────────────────
//
// The smart-amp DSP lives in coefficient books that require a PPC3
// (TI PurePath Console) export per speaker model — there is no
// documented "enable bit" in the book-0 register map. Until that
// pipeline exists these methods only track intent; they deliberately
// write NO registers (the datasheet-unlisted writes the old driver
// did here landed on unrelated registers).

bool TAS5825MCodec::smartAmpEnable(bool on) {
    if (!initialized_) {
        TAS5825_LOG("TAS5825M: smartAmpEnable(%d) — not initialized", on);
        return false;
    }
    smartAmpOn_ = on;
    TAS5825_LOG("TAS5825M: smart-amp %s (stub — needs PPC3 coefficient "
                "pipeline; factory protection thresholds remain active)",
                on ? "requested" : "off");
    return true;
}

bool TAS5825MCodec::calibrateSpeaker() {
    if (!initialized_) {
        TAS5825_LOG("TAS5825M: calibrateSpeaker — not initialized");
        return false;
    }
    TAS5825_LOG("TAS5825M: calibrateSpeaker (stub — using factory defaults)");
    return true;
}

int16_t TAS5825MCodec::readSpeakerTemp_C() {
    if (!initialized_ || !smartAmpOn_) return 0;
    return 0;   // needs the PPC3 pipeline (indirect DSP-RAM reads)
}

uint16_t TAS5825MCodec::readSpeakerExcursion_mm100() {
    if (!initialized_ || !smartAmpOn_) return 0;
    return 0;   // see readSpeakerTemp_C()
}

bool TAS5825MCodec::setIvSenseEnabled(bool on) {
    if (!initialized_) return false;
    TAS5825_LOG("TAS5825M: IV-sense %s (stub)", on ? "enable" : "disable");
    return true;
}

// ─── Diagnostics ──────────────────────────────────────────────────────────

void TAS5825MCodec::dumpRegisters() {
    if (!initialized_) {
        TAS5825_LOG("TAS5825M: dumpRegisters — not initialized");
        return;
    }
    TAS5825_LOG("─── TAS5825M register dump ───");
    selectBookPage(BOOK_00, PAGE_00);
    struct { uint8_t reg; const char* name; } regs[] = {
        {REG_DEVICE_CTRL2,  "DEVICE_CTRL2"},
        {REG_POWER_STATE,   "POWER_STATE"},
        {REG_FS_MON,        "FS_MON"},
        {REG_BCK_MON,       "BCK_MON"},
        {REG_CLKDET_STATUS, "CLKDET_STAT"},
        {REG_SAP_CTRL1,     "SAP_CTRL1"},
        {REG_DIG_VOL,       "DIG_VOL"},
        {REG_AGAIN,         "AGAIN"},
        {REG_PVDD_ADC,      "PVDD_ADC"},
        {REG_GPIO_CTRL,     "GPIO_CTRL"},
        {REG_GPIO1_SEL,     "GPIO1_SEL"},
        {REG_DIE_ID,        "DIE_ID"},
        {REG_CHAN_FAULT,    "CHAN_FAULT"},
        {REG_GLOBAL_FAULT1, "GLOBAL_FAULT1"},
        {REG_GLOBAL_FAULT2, "GLOBAL_FAULT2"},
        {REG_WARNING,       "WARNING"},
    };
    for (const auto& r : regs) {
        uint8_t v = 0;
        if (readRegister(r.reg, &v)) {
            TAS5825_LOG("  0x%02X %-13s : 0x%02X", r.reg, r.name, v);
        }
    }
}

uint8_t TAS5825MCodec::getDeviceControlRegister() {
    if (!initialized_) return 0xFF;
    selectBookPage(BOOK_00, PAGE_00);
    uint8_t v = 0;
    readRegister(REG_DEVICE_CTRL2, &v);
    return v;
}

uint8_t TAS5825MCodec::getFaultRegister() {
    return readFaultRegister();
}

bool TAS5825MCodec::testI2CConnection() {
    if (!i2c_) return false;
    return i2c_->probe(I2C_ADDR);
}

// ─── Private helpers ──────────────────────────────────────────────────────

bool TAS5825MCodec::writeRegister(uint8_t reg, uint8_t value) {
    if (!i2c_) return false;
    return i2c_->writeReg(I2C_ADDR, reg, &value, 1);
}

bool TAS5825MCodec::readRegister(uint8_t reg, uint8_t* value) {
    if (!i2c_ || !value) return false;
    return i2c_->readReg(I2C_ADDR, reg, value, 1);
}

bool TAS5825MCodec::selectBookPage(uint8_t book, uint8_t page) {
    if (!writeRegister(REG_PAGE, page)) return false;
    if (!writeRegister(REG_BOOK, book)) return false;
    return true;
}

bool TAS5825MCodec::waitForFsLock(uint32_t timeoutMs, uint8_t* outFsCode) {
    for (uint32_t elapsed = 0;; elapsed += FS_MON_POLL_INTERVAL_MS) {
        uint8_t fs = 0;
        readRegister(REG_FS_MON, &fs);
        fs &= 0x0F;
        if (fs != FS_ERROR) {
            if (outFsCode) *outFsCode = fs;
            return true;
        }
        if (elapsed >= timeoutMs) {
            if (outFsCode) *outFsCode = fs;
            return false;
        }
        SFX_DELAY_MS(FS_MON_POLL_INTERVAL_MS);
    }
}

bool TAS5825MCodec::configureAnalogGain() {
    selectBookPage(BOOK_00, PAGE_00);
    bool ok = writeRegister(REG_AGAIN, analogGainFor(supply_));
    if (ok) {
        TAS5825_LOG("TAS5825M: analog gain set for %s (AGAIN=0x%02X)",
                    supplyStr(supply_), analogGainFor(supply_));
    }
    return ok;
}

#endif // SFX_HAS_AUDIO
