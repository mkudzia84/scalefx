# tas5825m_beep — flash & run instructions

Bring-up probe for the TAS5825M audio amplifier on the ScaleFX HubFX
board (ESP32-S3). It initializes the codec with the M-variant-strict
sequence, plays a 1 kHz beep (200 ms on / 800 ms off), and prints every
register access + a 2 s status heartbeat on the serial console.

## What you need

- The HubFX board, powered (the amp's PVDD rail must be up or the codec
  will report UVP faults — USB power alone runs the logic but may not
  run the amplifier).
- A speaker on the amp output.
- USB cable to the board's UART/console port (shows up as a COM port,
  CH343 driver on Windows if it doesn't appear).
- `esptool` — `pip install esptool` (any recent version).

## Flash (prebuilt binary)

One command, from the `firmware/` folder — writes bootloader + partition
table + app in one image:

```
esptool --chip esp32s3 --port COMxx --baud 921600 write_flash 0x0 firmware.factory.bin
```

Replace `COMxx` with the board's port. If the board doesn't enter the
bootloader automatically: hold BOOT, tap RESET, release BOOT, retry.

(Equivalent split write, if you ever need it:
`0x0 bootloader.bin  0x8000 partitions.bin  0xe000 ota_data_initial.bin
0x10000 firmware.bin`.)

The partition table matches the production firmware, so any configs
stored on the board survive. To return the board to normal duty
afterwards, reflash the production HubFX firmware.

## Watch the output

Open the same COM port at **115200 baud** (PuTTY / TeraTerm /
`pio device monitor` / `python -m serial.tools.miniterm COMxx 115200`)
and press RESET. You'll see:

1. An I2C bus scan — the codec must ACK at **0x4C**.
2. A silicon identity check — `DIE_ID=0x95 — TAS5825M silicon CONFIRMED`.
3. `PHASE 1` — reset + park, each write logged with a readback
   (`rb=0x.. OK`).
4. I2S start + `PHASE 2` — config, then `polling FS_MON...` until the
   codec locks onto the 48 kHz clocks (expect `FS_MON LOCKED: 0x09`).
5. `*** PLAY — codec is live, listen for the beep ***` and a beeping
   speaker.
6. `[hb #N]` heartbeat lines every 2 s with the live PVDD (amp rail)
   voltage and decoded fault bits. If the codec drops out of PLAY, the
   probe auto-recovers and logs it.

## If it doesn't beep

| Console shows | Likely cause |
|---|---|
| No ACK at 0x4C in the scan | I2C wiring / codec 3V3 (DVDD) supply |
| `DIE_ID` not 0x95 | Not TAS5825M silicon, or a flaky I2C bus |
| `FS_MON NEVER LOCKED` | I2S clock path GPIO17 (BCLK) / GPIO18 (LRCLK) to the codec — the CLKDET decode names the unhappy clock |
| `PLAY FAILED` + `PVDD_UV(supply!)` | Amp supply rail missing/sagging — check the heartbeat's `PVDD=..V` reading |
| `PLAY FAILED` + `OTSD(thermal!)` | Overtemp shutdown — check for shorts on the speaker outputs |
| `L_OC`/`R_OC` in the CHF decode | Output over-current — speaker/wiring short |
| `PLAY` but silent | Speaker wiring; scope OUT_A/OUT_B (should show 1 kHz bursts) |
| Repeated `recovery #N` | Intermittent fault — note which fault bit re-latches each time |

Please capture the full console log from reset (a minute or two is
plenty) — it contains everything needed to diagnose remotely.

## Contents

- `firmware/` — prebuilt binaries (`firmware.factory.bin` is the one to
  flash; `firmware.elf` is for decoding crash backtraces, no need to
  touch it).
- `source/` — the complete PlatformIO project (`pio run -e esp32s3` to
  rebuild; pure ESP-IDF, no Arduino).
- `codec_reference/` — the ScaleFX TAS5825M driver + shared register map
  the probe's sequence mirrors, for reference only (not needed to run
  the test).
